package com.redshift.jumpcalc;

public class JumpCalcGUI {
}
