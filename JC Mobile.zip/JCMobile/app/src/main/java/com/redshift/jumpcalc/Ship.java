package com.redshift.jumpcalc;

public class Ship {

    String name;
    float range;
    int routeTime;
    boolean hasmodifiers;

}